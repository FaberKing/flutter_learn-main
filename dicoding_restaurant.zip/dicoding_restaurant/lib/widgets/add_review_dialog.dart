import 'package:dicoding_restaurant/data/provider/add_review_notifier.dart';

import 'package:flutter/material.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';

Future<void> addReviewDialog(BuildContext context, WidgetRef ref, String id) {
  TextEditingController name = TextEditingController();
  TextEditingController reviews = TextEditingController();

  return showDialog(
    context: context,
    builder: (context) {
      return AlertDialog(
        title: const Text('Add Your Reviews :'),
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(
                labelText: 'Enter Your Name',
                labelStyle: TextStyle(color: Colors.black),
              ),
            ),
            const SizedBox(
              height: 5,
            ),
            TextField(
              controller: reviews,
              decoration: const InputDecoration(
                labelText: 'Enter Your Review',
                labelStyle: TextStyle(color: Colors.black),
              ),
            )
          ],
        ),
        actions: [
          TextButton(
            child: const Text(
              'CANCEL',
              style: TextStyle(color: Colors.black),
            ),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
          TextButton(
            child: const Text(
              'OK',
              style: TextStyle(color: Colors.black),
            ),
            onPressed: () {
              Map answer = {
                'id': id,
                'name': name.text,
                'review': reviews.text
              };
              ref
                  .read(addReviewNotifierProvider.notifier)
                  .entryNewReview(answer, context)
                  .whenComplete(
                () {
                  Navigator.pop(context);
                },
              );
            },
          ),
        ],
      );
    },
  );
}
