import 'package:dicoding_restaurant/data/api_services.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AddReviewNotifier extends StateNotifier<bool> {
  ApiService apiService = ApiService();
  AddReviewNotifier() : super(false);

  Future<void> entryNewReview(Map answer, BuildContext context) async {
    try {
      await apiService.addReviewRestaurant(answer);
      return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            content: const Text('Berhasil'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('OK'))
            ],
          );
        },
      );
    } catch (e) {
      return showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            content: const Text('Ada kendala, Silahkan coba kembali'),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('OK'))
            ],
          );
        },
      );
    }
  }
}

final addReviewNotifierProvider =
    StateNotifierProvider<AddReviewNotifier, bool>((ref) {
  return AddReviewNotifier();
});
