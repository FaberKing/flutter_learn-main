import 'dart:io';

import 'package:dicoding_restaurant/common/state_restaurant.dart';
import 'package:dicoding_restaurant/data/api_services.dart';
import 'package:dicoding_restaurant/data/model/restaurant_detail.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class RestaurantDetailNotifier extends StateNotifier<RestaurantState> {
  ApiService apiService = ApiService();

  RestaurantDetailNotifier(String id, {required this.apiService})
      : super(RestaurantState.loading) {
    allRestaurantList(id);
  }

  late RestaurantDetail _restaurantResult;

  String _message = '';

  String get message => _message;

  RestaurantDetail get result => _restaurantResult;

  Future<dynamic> allRestaurantList(id) async {
    try {
      state = RestaurantState.loading;
      // final restaurant = await ref.watch(listProvider).fullRestaurantList();
      final restaurant = await apiService.fullRestaurantDetail(id);
      if (restaurant.restaurant.toString().isEmpty) {
        state = RestaurantState.noData;
        return _message = 'Empty Data';
      } else {
        state = RestaurantState.hasData;
        return _restaurantResult = restaurant;
      }
    } on SocketException catch (_) {
      state = RestaurantState.error;
      return _message = 'No Internet Connection';
    } catch (e) {
      state = RestaurantState.error;
      return _message = 'Error ---> $e';
    }
  }
}

final restaurantDetailProvider = StateNotifierProvider.family<
    RestaurantDetailNotifier, RestaurantState, String>(
  (ref, id) => RestaurantDetailNotifier(apiService: ApiService(), id),
);
