enum RestaurantState { loading, noData, hasData, error }
